/** Automatically generated file. DO NOT MODIFY */
package edu.ncsu.ngohara.mobilechatroomclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}